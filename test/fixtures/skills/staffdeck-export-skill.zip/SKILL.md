# 票据字段提取

## 技能用途

从发票的文本或图片中，提取金额、抬头、税号等结构化字段，输出规范的 JSON，供后续报销、记账、查验等环节使用。适用于增值税专用发票、普通发票、电子发票、行程单、定额发票等常见票据。

## 何时使用

- 用户上传或粘贴了发票图片、PDF、扫描件或 OCR 文本，需要把关键信息结构化。
- 报销、入账、发票查验等流程需要先拿到发票的结构化字段。

## 输入

- 发票图片 / PDF / 扫描件，或已识别的发票文本。
- 若为图片，先进行 OCR/视觉识别得到文本再提取。

## 需要提取的字段

按下列字段提取，缺失的填 `null`，不要臆造：

| 字段 | 说明 |
| --- | --- |
| `invoice_type` | 发票类型：增值税专用发票/普通发票/电子普通发票/行程单等 |
| `invoice_code` | 发票代码 |
| `invoice_number` | 发票号码 |
| `invoice_date` | 开票日期 YYYY-MM-DD |
| `buyer_name` | 购买方名称（抬头） |
| `buyer_tax_no` | 购买方纳税人识别号（税号） |
| `seller_name` | 销售方名称 |
| `seller_tax_no` | 销售方纳税人识别号 |
| `amount_excl_tax` | 金额（不含税） |
| `tax_rate` | 税率 |
| `tax_amount` | 税额 |
| `total_amount` | 价税合计（含税总额） |
| `check_code` | 校验码 |
| `items` | 商品/服务明细列表，每项含 `name`/`quantity`/`unit_price`/`amount` |

## 执行步骤

1. 若输入是图片/PDF，先识别为文本。
2. 逐字段定位并提取，注意区分购买方与销售方（不要混淆抬头与销方）。
3. 金额类字段统一转为数字（去掉「¥」、千分位逗号），保留两位小数。
4. 校验一致性：`amount_excl_tax + tax_amount` 应约等于 `total_amount`；不一致时在 `notes` 中标注。
5. （可选）调用工具 `invoice.verify` 对提取结果做真伪与要素完整性查验。
6. 输出结构化 JSON。

## 工具调用（可选）

本技能可调用发票查验工具对提取结果进行校验：

- 工具名：`invoice.verify`
- 传入提取到的 `invoice_code`、`invoice_number`、`invoice_date`、`total_amount`（作为 amount）、`check_code`、`seller_name`（作为 seller）、`buyer_name`（作为 buyer）。
- 将返回的 `authentic`/`fields_complete`/`risk_level` 一并汇入结果。

## 输出格式

严格输出如下 JSON：

```json
{
  "invoice_type": "增值税电子普通发票",
  "invoice_code": "011001900111",
  "invoice_number": "12345678",
  "invoice_date": "2026-07-05",
  "buyer_name": "上海某某科技有限公司",
  "buyer_tax_no": "91310000XXXXXXXXXX",
  "seller_name": "北京某某服务有限公司",
  "seller_tax_no": "91110000XXXXXXXXXX",
  "amount_excl_tax": 3018.87,
  "tax_rate": "6%",
  "tax_amount": 181.13,
  "total_amount": 3200.00,
  "check_code": "12345678901234567890",
  "items": [
    { "name": "技术服务费", "quantity": 1, "unit_price": 3018.87, "amount": 3018.87 }
  ],
  "verify": { "authentic": true, "fields_complete": true, "risk_level": "low" },
  "notes": ""
}
```

## 注意事项

- 只提取票面真实存在的信息，识别不清或缺失的字段填 `null` 并在 `notes` 说明。
- 税号为字母数字组合，注意 0/O、1/l 等易混字符。
- 金额一律用数字类型，不带货币符号。